#include "Camera.h"

Vector2D camOffset = Vector2D(0, 0);