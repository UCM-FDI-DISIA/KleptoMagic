#pragma once
#include "../utils/Vector2D.h"

extern Vector2D camOffset;